# Consent Monitor — GitHub Monorepo (v2)

Suite transparan & berbasis persetujuan:
- `android-sender/` — aplikasi sumber data (notifikasi, app foreground, lokasi opsional).
- `android-viewer/` — aplikasi admin (lihat event, ringkasan, ekspor CSV).
- `web-dashboard/` — dashboard statis (Top Apps, **Peak Hours**, ekspor CSV harian, ringkasan harian + **AI**).
- `functions/` — Firebase Cloud Functions:
  - `rollupDailySummary` (rekap harian + **histogram 24 jam**),
  - `aiSummarizeDaily` (opsional, gunakan `OPENAI_API_KEY` / `functions.config().openai.key`),
  - `purgeOldEvents` (TTL 30 hari).

## Cepat Mulai
1) Commit ke repo GitHub-mu.
2) **Build APK debug**: Actions → **Build Android APKs** → unduh artefak.
3) **(Opsional) APK release bertanda tangan**: Actions → **Build Signed Release APKs** setelah set secrets (lihat bagian *Signing*).
4) **Web**: isi `firebaseConfig` di `web-dashboard/index.html`, lalu Actions → **Deploy Web Dashboard to Pages**.
5) **Functions**: set secrets (`FIREBASE_SERVICE_ACCOUNT`, `PROJECT_ID`, opsional `OPENAI_API_KEY`) lalu Actions → **Deploy Firebase Functions**.

## Signing (APK Release)
Tambahkan Repository Secrets:
- `KEYSTORE_BASE64` — isi base64 dari keystore `.jks`
- `KEY_ALIAS` — alias kunci
- `KEY_PASS` — password key
- `STORE_PASS` — password keystore

Workflow **Build Signed Release APKs** akan:
- decode keystore → `keystore.jks`
- export env → digunakan oleh *signingConfigs* di masing-masing app
- menjalankan `assembleRelease` untuk **android-sender** & **android-viewer**

> Catatan: upload `google-services.json` ke `android-sender/app/` dan `android-viewer/app/` agar integrasi Firebase berfungsi di runtime. Build tetap jalan tanpa file ini.

## Etika & Hukum
Gunakan **hanya** dengan persetujuan pemilik perangkat. Aplikasi menunjukkan notifikasi berjalan & menyediakan layar persetujuan.
